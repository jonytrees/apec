jQuery(document).ready(function(){
    jQuery('.scrollbar-inner').scrollbar();
});